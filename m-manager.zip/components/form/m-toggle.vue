<template>
    <div>
        <label class="toggle" for="toggle">
            <input id="toggle" class="toggle__input" type="checkbox" />
            <div class="toggle__fill"></div>
        </label>
    </div>
</template>

<script>
export default {
    name: 'MToggle',
}
</script>

<style scoped></style>
