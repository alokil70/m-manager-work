<template>
    <div class="center">{{ slot }}</div>
</template>

<script>
export default {
    name: 'MCard',
    props: {},
}
</script>

<style scoped></style>
