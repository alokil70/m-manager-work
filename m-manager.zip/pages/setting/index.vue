<template>
    <div>
        <h1>
            pages/setting/index.vue доступно при наличии у пользователя admin =
            true
        </h1>
    </div>
</template>

<script>
export default {
    name: 'Index',
    auth: true,
}
</script>

<style scoped></style>
