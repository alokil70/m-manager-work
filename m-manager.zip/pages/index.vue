<template>
    <div class="container">
        <h1>pages/index.vue</h1>
        <div></div>
    </div>
</template>

<script>
export default {}
</script>

<style>
body {
    background-color: #f4f5f8;
    min-height: 100vh;
}
</style>
